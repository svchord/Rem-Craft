export let config = {
  plugin: {
    tabBar: true, // 顶部页签栏
    status: true, // 底部状态栏
    listIndent: true, // 文档树缩进
    bullet: true, //子弹流列表块辅助线
  },
};
